# File DB_Connect.py

import MySQLdb
from configparser import ConfigParser


class DBConnector:
    def __init__(self, connect_to_db_now=False):
        self.connection = None
        if connect_to_db_now:
            self.connect_to_db()

    def connect_to_db(self):
        self.connection = MySQLdb.connect(user='root', passwd='Password', host='127.0.0.1', db='device_mgmt')
        if self.connection.open:
            print("DB is connected - connect_to_db")

    def connect_to_db_with_dict(self):
        db_config = {
            'user': 'root',
            'passwd': 'Password',
            'host': '127.0.0.1',
            'db': 'device_mgmt'}
        self.connection = MySQLdb.connect(**db_config)
        if self.connection.open:
            print("DB is connected - connect_to_db_with_dict")

    def connect_to_db_with_parsed_config_file(self):
        db_config = self._read_config_details_from_file()
        self.connection = MySQLdb.connect(**db_config)
        if self.connection.open:
            print("DB is connected - connect_to_db_with_parsed_config_file")

    def _read_config_details_from_file(self):
        parser = ConfigParser()
        parser.read('db_config.txt')
        db = {}
        if parser.has_section('device_mgmt'):
            items = parser.items('device_mgmt')
            for item in items:
                db[item[0]] = item[1]
        else:
            raise Exception('{0} not found in the {1} file'.format('mysql', 'db_config.txt'))

        return db

    def close_db_connection(self):
        if self.connection.open:
            print("closing connection - close_db_connection")
            self.connection.close()


if __name__ == "__main__":
    connector = DBConnector(True)
    connector.close_db_connection()
    connector = DBConnector(False)
    connector.connect_to_db_with_dict()
    connector.close_db_connection()
    connector.connect_to_db_with_parsed_config_file()
    connector.close_db_connection()
