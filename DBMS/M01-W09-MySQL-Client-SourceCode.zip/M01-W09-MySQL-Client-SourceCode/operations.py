# File Operations.py
from DB_connect import DBConnector
import MySQLdb.cursors as cursor


class Transact:
    def __init__(self):
        self.connector = DBConnector(False)
        self.connector.connect_to_db_with_dict()
        self.connection = self.connector.connection
        self.connection.query("Use device_mgmt")

    def close_connection(self):
        self.connector.close_db_connection()

    def select_data(self):
        query_statement = """SELECT * FROM device WHERE device_category = 1"""
        self.connection.query(query_statement)
        result_set = self.connector.connection.store_result()
        print(result_set.fetch_row(3))
        print("")
        rows = result_set.fetch_row(0, 1)
        for row in rows:
            print(row)
            print(type(row['id']))

    def select_data_with_cursor(self):
        cursor_obj = cursor.DictCursor(self.connector.connection)
        # cursor_obj.connection = self.connector.connection
        query_statement = """SELECT * FROM device"""
        cursor_obj.execute(query=query_statement)
        print(cursor_obj.fetchone())
        print("")
        print(cursor_obj.fetchmany(4))
        print("")
        rows = cursor_obj.fetchall()
        for row in rows:
            print(row)
            
    def insert_a_new_row(self):
        cursor_obj = self.connection.cursor()
        insert_statement = """INSERT INTO device(device_category, device_name, device_description, inventory)
        values(3, "Gas pressure gauge", "Measures gas pressure and sends notification when threshold exceeds", 20)"""
        result = cursor_obj.execute(insert_statement)
        print(f"{result} Row(s) affected.")
        self.connection.commit()

    def insert_many_rows(self):
        cursor_obj = self.connection.cursor(cursorclass=cursor.DictCursor)

        insert_statement = """INSERT INTO device(device_category, device_name, device_description, inventory)
        values(%s, %s, %s, %s)"""
        devices = [(3, 'Temperature sensor', 'Observes temperature of equpment attached to', 23),
                   (3, 'Carbon Monoxide sensor', 'Senses presence of Carbon Monoxide', 12),
                   (4, 'GPS Monitor', 'Gives live location of vehicle attached to', 34)]

        result = cursor_obj.executemany(insert_statement, devices)
        print(f"{result} Row(s) affected.")
        self.connection.commit()

    def delete_records(self):
        cursor_obj = self.connection.cursor()
        delete_statement = """DELETE FROM device WHERE id = %s"""
        result = cursor_obj.execute(delete_statement, (12,))
        self.connection.commit()

    def update_records(self):
        cursor_obj = self.connection.cursor()
        update_statement = """UPDATE device SET device_name = %s, device_description = %s WHERE id = %s"""
        data = ('Nitrogen Sensor', 'Senses Nitrogen gas', '13')
        result = cursor_obj.execute(update_statement, data)
        self.connection.commit()
        
        
if __name__ == "__main__":
    obj = Transact()
    obj.select_data()
    # print()
    # obj.select_data_with_cursor()
    # print()
    # obj.insert_a_new_row()

    # obj.delete_records()
    # obj.insert_many_rows()
    # obj.select_data_with_cursor_and_condition()
    #obj.update_records()
    # obj.select_data_with_cursor_and_condition()
    obj.close_connection()