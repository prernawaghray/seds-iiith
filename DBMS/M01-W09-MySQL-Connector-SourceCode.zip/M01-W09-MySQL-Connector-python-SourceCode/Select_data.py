from mysql.connector.cursor import MySQLCursorPrepared

from DB_connect import DBConnect


def run_query(db_connection, query_statement):
    if not query_statement:
        return None
    cursor = db_connection.connection.cursor()
    cursor.execute(query_statement)
    return cursor


def prepare_query(db_connection, query_statement, params):
    if not query_statement:
        return None
    cursor = db_connection.connection.cursor(prepared=True)
    cursor.execute(query_statement, params)
    return cursor


def show_cursor_details(cursor):
    print("rowcount (initial):", cursor.rowcount, end='\n\n')
    print("column_names:", cursor.column_names, end='\n\n')
    print("with_rows:", cursor.with_rows, end='\n\n')
    print("description: ", end="")
    print(cursor.description)
    print("\nstatement:", cursor.statement, end='\n\n')
    print("lastrowid:", cursor.lastrowid, end='\n\n')
    print("rowcount (final):", cursor.rowcount, end='\n\n')
    print(cursor.fetchone())
    print("rowcount (final):", cursor.rowcount, end='\n\n')

    for row in cursor:
        print(row)


if __name__ == "__main__":
    db_connection = DBConnect()
    db_connection.connect_to_db()

    # select_statement = 'select * from device'
    # cursor = run_query(db_connection, select_statement)
    # show_cursor_details(cursor)

    prepared_statement = "select * from device where id > %s"
    params = tuple((0,))
    cursor = prepare_query(db_connection, prepared_statement, params)
    show_cursor_details(cursor)

    cursor.close()
    db_connection.close_db_connection()
