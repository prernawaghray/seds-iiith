import mysql.connector
from configparser import ConfigParser
from mysql.connector import errorcode


class DBConnect:
    def __init__(self):
        self.connection = None

    def connect_to_db(self):
        try:
            self.connection = mysql.connector.connect(user='root', password='MyNewPass',
                                                      host='127.0.0.1', database='device_mgmt')
        except mysql.connector.Error as err:
            print("err.errno - ", err.errno)
            print("err.msg - ", err.msg)
            print("err.sqlstate - ", err.sqlstate)
            print("err.args - ", err.args)
            print("err.__cause__ - ", err.__cause__)
            print(err)
        else:
            if self.connection.is_connected():
                print("Connected to - device_mgmt")


    def connect_to_db_with_dict(self):
        db_config = {
            'user': 'root',
            'password': 'MyNewPass',
            'host': '127.0.0.1',
            'database': 'device_mgmt'}
        try:
            self.connection = mysql.connector.connect(**db_config)
        except mysql.connector.Error as err:
            print("err.errno - ", err.errno)
            print("err.msg - ", err.msg)
            print("err.sqlstate - ", err.sqlstate)
            print("err.args - ", err.args)
            print("err.__cause__ - ", err.__cause__)
            print(err)
        else:
            if self.connection.is_connected():
                print("Connected to - device_mgmt")

    def close_db_connection(self):
        if self.connection.is_connected():
            self.connection.close()
            print("DB connection closed")


    def connect_to_db_with_config_file(self):
        try:
            self.connection = mysql.connector.connect(option_files='my_conf.txt', option_groups=['connection_details'])
        except mysql.connector.Error as err:
            print("err.errno - ", err.errno)
            print("err.msg - ", err.msg)
            print("err.sqlstate - ", err.sqlstate)
            print("err.args - ", err.args)
            print("err.__cause__ - ", err.__cause__)
            print(err)
        else:
            if self.connection.is_connected():
                print("Connected to - device_mgmt")

    def connect_to_db_with_parsed_config_file(self):
        db_config = self._read_config_details_from_file()
        try:
            self.connection = mysql.connector.connect(**db_config)
        except mysql.connector.Error as err:
            print("err.errno - ", err.errno)
            print("err.msg - ", err.msg)
            print("err.sqlstate - ", err.sqlstate)
            print("err.args - ", err.args)
            print("err.__cause__ - ", err.__cause__)
            print(err)
        else:
            if self.connection.is_connected():
                print("Connected to - device_mgmt")

    def _read_config_details_from_file(self):
        parser = ConfigParser()
        parser.read('db_config.txt')
        db_details = {}
        if parser.has_section('mysql'):
            items = parser.items('mysql')
            for item in items:
                db_details[item[0]] = item[1]
        else:
            raise Exception('{0} not found in the {1} file'.format('mysql', 'db_config.txt'))

        return db_details


if __name__ == "__main__":
    connector = DBConnect()
    connector.connect_to_db()
    connector.close_db_connection()

    connector.connect_to_db_with_dict()
    connector.close_db_connection()

    connector.connect_to_db_with_config_file()
    connector.close_db_connection()

    connector.connect_to_db_with_parsed_config_file()
    connector.close_db_connection()