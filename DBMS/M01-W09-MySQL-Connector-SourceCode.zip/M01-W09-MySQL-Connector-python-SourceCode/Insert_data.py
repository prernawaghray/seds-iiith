from mysql.connector.cursor import MySQLCursorPrepared

from DB_connect import DBConnect


def insert_in_table(db_connection, statement, params):
    if not statement:
        return None
    cursor = db_connection.connection.cursor(prepared=True)
    cursor.execute(statement, params)
    db_connection.connection.commit()
    cursor.close()


def insert_new_devices(db_connection):
    insert_statement = """INSERT INTO device (device_category, device_name, device_description, inventory) 
    values (%s, %s, %s, %s)"""

    values = (1, "Smart Pen", "Smart pen writes and also checks for meaning in a selected language", 33)
    insert_in_table(db_connection, insert_statement, values)


if __name__ == "__main__":
    db_connection = DBConnect()
    db_connection.connect_to_db()
    insert_new_devices(db_connection)

    db_connection.close_db_connection()
