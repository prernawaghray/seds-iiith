from DB_connect import DBConnect


def update_record(db_connection, statement, params):
    if not statement:
        return None
    cursor = db_connection.connection.cursor(prepared=True)
    cursor.execute(statement, params)
    db_connection.connection.commit()
    cursor.close()


def update_devices(db_connection):
    update_statement = """Update device set device_name = %s WHERE id = %s"""
    values = ("Smarter Pen", 19)
    update_record(db_connection, update_statement, values)


if __name__ == "__main__":
    db_connection = DBConnect()
    db_connection.connect_to_db()
    update_devices(db_connection)

    db_connection.close_db_connection()
