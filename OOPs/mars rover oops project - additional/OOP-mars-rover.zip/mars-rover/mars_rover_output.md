Rover already present in the given location
Rover already present in the given location
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ L _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ L _ _ _ _ _
_ _ _ _ _ D _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
Rover clash !!
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ L _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ L _ _ _ _ _
_ _ _ _ _ D _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _
(4, 3)
1
('Invalid input given', '$')
0
False
True