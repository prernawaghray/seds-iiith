from Rover import Rover

class MarsRover(Rover):
    def navigate(self,inp,tc):
        #input here is a direction for movement string made of L/l,R/r,F/f,B/b e.g. "LfrrBFllFF", returns success/failure. Stops if it sees any other object in its path. If the rover reaches the destination then it is success else it is failure. Works only when charge is available on the rover, gives update about the charging needed
        pass
		
    def __move_left(self, tc):
    #private function
        pass
		
    def __move_right(self, tc):
    #private function
        pass
		
    def __move_forward(self, tc):
        #private function
        pass
		
    def __move_backward(self, tc):
        #private function
        pass