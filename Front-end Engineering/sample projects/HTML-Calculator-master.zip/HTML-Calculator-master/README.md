# HTML-Calculator
## A Calculator made with HTML, CSS and JavaScript <br><br>

Subscribe on my channel: https://www.youtube.com/channel/UCrx20bdxcCQhcmL3x0Rqrmw <br>
Put like on the Calculator video: https://youtu.be/mA6ATICxdiM <br>


Try also the scientific calculator: https://github.com/OrangoMango/HTML-Scientific-Calculator <br><br>
![Calculator](https://user-images.githubusercontent.com/61402409/79010798-f7a4b700-7b62-11ea-8fb0-7a54fae8b726.jpeg)
<br>Program Output
