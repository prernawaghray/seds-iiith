# Calculator
A Calculator App with dark mode. Built using HTML, CSS and JavaScript. Feel free to check out the code and don't forget to star the repo.⭐

![cal](https://user-images.githubusercontent.com/44538497/95009574-bb996d00-0640-11eb-938f-dd433ae70c58.png)
