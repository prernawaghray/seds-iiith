
var email_valid = false;
var password_valid = false;
var all_enquiries = [];

function calculate() {  
    ctc = monthly_salary_form.ctc.value;
    deductions = monthly_salary_form.deductions.value;
    basic = 0.5 * ctc;
    employment_tax = 2500;
    gratuity = 0.0481 * basic;
    pf = 0.15 * basic;
    is_metro = monthly_salary_form.metro.checked;
    switch(is_metro)
    {
        case true:
            hra = 0.5*basic;
            break;

        case false:
            hra = 0.4*basic;
            break;

        default:
            hra = 0.4*basic;
    }
    // hra = is_metro ? 0.5*basic : 0.4*basic;
    standard_deductions = 50000;
    taxable = ctc - standard_deductions - employment_tax - hra - deductions - gratuity - (2*pf)
    console.log("taxable:", taxable);
    
    bracket_1 = taxable > 500000 ? 500000: taxable; // 10%  (0-5L)
    taxable = taxable > 500000 ? taxable - 500000: 0;
    bracket_2 = taxable > 500000 ? 500000: taxable; // 20% (5-10L)
    taxable = taxable > 500000 ? taxable - 500000: 0;
    bracket_3 = taxable;

    tax = (0.1 * bracket_1) + (0.2 * bracket_2) + (0.3 * bracket_3);
    console.log("tax:", tax);
    in_hand_yearly = ctc - employment_tax - (2*pf) - gratuity - tax;

    console.log("in_hand_yearly:", in_hand_yearly);

    in_hand_monthly = in_hand_yearly / 12;

    in_hand_monthly = in_hand_monthly.toFixed(2);

    monthly_salary_form.basic.value = basic;
    monthly_salary_form.employmenttax.value = employment_tax;
    monthly_salary_form.gratuity.value = gratuity;
    monthly_salary_form.pf.value = pf;
    monthly_salary_form.hra.value = hra;
    monthly_salary_form.incometax.value = tax;

    monthly_salary_form.monthly.value = in_hand_monthly;

    // In Hand CTC - 2500 (employment tax) - HRA (40% or 50%) 
    document.getElementById('show-monthly').style.display = 'block';
}

function toggle_password(){
    password = document.querySelector('#password');
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);

    toggle_button = document.getElementById('togglePasswordButton');
    if (toggle_button.classList.contains('fa-eye')){
        toggle_button.classList.remove('fa-eye');
        toggle_button.classList.add('fa-eye-slash');
    } else {
        toggle_button.classList.remove('fa-eye-slash');
        toggle_button.classList.add('fa-eye');
    }
}

function validate_email(email){
    const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function email_validation(emailid){
    if (validate_email(emailid.value)){
        emailid.classList.add('valid');
        emailid.classList.remove('invalid');
        emailid.nextElementSibling.style.display = 'none';
        email_valid = true;
    }
    else {
        emailid.classList.add('invalid');
        emailid.classList.remove('valid');
        emailid.nextElementSibling.style.display = 'block';
        email_valid = false;
    }
}

function password_validation(password){
    if (5 <= password.value.length && password.value.length <= 8){
        password.classList.add('valid');
        password.classList.remove('invalid');
        document.getElementById('helpIdPass').style.display = 'none';
        password_valid = true;
    }else{
        password.classList.add('invalid');
        password.classList.remove('valid');
        document.getElementById('helpIdPass').style.display = 'block';
        password_valid = false;
    }
}

function form_validation(form){
    if (email_valid && password_valid){
        document.getElementById('submitBtn').removeAttribute("disabled");
    }
    else{
        document.getElementById('submitBtn').setAttribute("disabled", true);
    }
}


//Comparator Function    
function get_sorting_order(property) {    
    return function(x, y) {    
        if (x[property] > y[property]) {    
            return 1;    
        } else if (x[property] < y[property]) {    
            return -1;    
        }    
        return 0;    
    }
}

function add_enquiry(hiremeform) {  
    name_of_person = hiremeform.name.value;
    email = hiremeform.email.value;
    exp = hiremeform.experience.value;
    role = hiremeform.role.value;

    var hiregroup = hiremeform.hiregroup;
    var selectedHiregroup;

    for(var i = 0; i < hiregroup.length; i++) {
        if(hiregroup[i].checked)
            selectedHiregroup = hiregroup[i].value;
    }
    console.log(selectedHiregroup);
    
    var skills = []
    var checkboxes = hiremeform.querySelectorAll('input[type=checkbox]:checked')

    for (var i = 0; i < checkboxes.length; i++) {
        skills.push(checkboxes[i].name)
    }

    comment = hiremeform.comment.value;

    enquiry = {
        "name": name_of_person,
        "email": email,
        "experience_required": exp,
        "role": role,
        "will_hire": selectedHiregroup,
        "skills": skills,
        "comment": comment
    }

    all_enquiries.push(enquiry);
    all_enquiries.sort(get_sorting_order('experience_required'));

    console.log(all_enquiries);
    alert('Thank you for your enquiry. I will reach out to you within 2 days.');
    hiremeform.reset();
    var div = document.createElement("div");
    div.classList.add('form-control')
    div.innerHTML = JSON.stringify(enquiry);
    enquiries = document.getElementById('enquiries');
    enquiries.append(div);
}

var monthly_salary_form = document.getElementById("form_monthly_salary");
function handleForm(event) { event.preventDefault(); } 
monthly_salary_form.addEventListener('submit', handleForm);

var hiremeform = document.getElementById("hiremeform");
function handleForm(event) { event.preventDefault(); } 
hiremeform.addEventListener('submit', handleForm);